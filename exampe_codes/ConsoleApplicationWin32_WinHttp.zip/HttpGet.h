#pragma once

#include <iostream>
#include <Windows.h>

#ifndef DEFINE_WIN_HTTP
#define DEFINE_WIN_HTTP 1
#include <Winhttp.h>
#pragma comment (lib, "winhttp.lib")
#endif

// http://eternalwindows.jp/network/winhttp/winhttp02.html
struct HttpGet
{
	int Request()
	{
		HINTERNET      hSession, hConnect, hRequest;
		URL_COMPONENTS urlComponents;
		WCHAR          szHostName[256], szUrlPath[2048];
		WCHAR          szUrl[] = L"http://eternalwindows.jp/network/winhttp/sample2.php?msg=abc";
		DWORD          dwSize;
		DWORD          dwStatusCode;
		BYTE           buffer[4096];

		hSession = WinHttpOpen(L"sample", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
		if (hSession == NULL)
			return -1;

		ZeroMemory(&urlComponents, sizeof(URL_COMPONENTS));
		urlComponents.dwStructSize = sizeof(URL_COMPONENTS);
		urlComponents.lpszHostName = szHostName;
		urlComponents.dwHostNameLength = sizeof(szHostName) / sizeof(WCHAR);
		urlComponents.lpszUrlPath = szUrlPath;
		urlComponents.dwUrlPathLength = sizeof(szUrlPath) / sizeof(WCHAR);

		if (!WinHttpCrackUrl(szUrl, lstrlenW(szUrl), 0, &urlComponents)) {
			WinHttpCloseHandle(hSession);
			return -2;
		}

		hConnect = WinHttpConnect(hSession, szHostName, INTERNET_DEFAULT_PORT, 0);
		if (hConnect == NULL) {
			WinHttpCloseHandle(hSession);
			return -3;
		}

		hRequest = WinHttpOpenRequest(hConnect, L"GET", szUrlPath, NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);
		if (hRequest == NULL) {
			WinHttpCloseHandle(hConnect);
			WinHttpCloseHandle(hSession);
			return -4;
		}

		if (!WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0)) {
			WinHttpCloseHandle(hRequest);
			WinHttpCloseHandle(hConnect);
			WinHttpCloseHandle(hSession);
			return -5;
		}

		WinHttpReceiveResponse(hRequest, NULL);

		dwSize = sizeof(DWORD);
		WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &dwStatusCode, &dwSize, WINHTTP_NO_HEADER_INDEX);
		if (dwStatusCode == HTTP_STATUS_OK) 
		{
			WinHttpReadData(hRequest, buffer, sizeof(buffer), NULL);

			std::cout << "���� Body" << buffer << std::endl;
		}
		else {
			TCHAR szBuf[256];
			wsprintf(szBuf, TEXT("Status Code %d"), dwStatusCode);
			std::wcout << "����" << szBuf << std::endl;
		}

		WinHttpCloseHandle(hRequest);
		WinHttpCloseHandle(hConnect);
		WinHttpCloseHandle(hSession);

		return 0;
	}
};