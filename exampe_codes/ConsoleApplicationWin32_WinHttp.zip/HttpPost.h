﻿#pragma once

#include <iostream>
#include <Windows.h>

#ifndef DEFINE_WIN_HTTP
#define DEFINE_WIN_HTTP 1
	#include <Winhttp.h>
	#pragma comment (lib, "winhttp.lib")
#endif


// http://eternalwindows.jp/network/winhttp/winhttp02.html
struct HttpPost
{
	static int Request()
	{
		WCHAR          szHostName[256], szUrlPath[2048];
		WCHAR          szUrl[] = L"http://localhost/Request/Login";
		URL_COMPONENTS urlComponents;

		WCHAR          szHeader[] = L"Content-Type: application/json\r\n";
		DWORD          dwHeaderLength = lstrlenW(szHeader);
		
		auto hSession = WinHttpOpen(L"Sample Application/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
		if (hSession == NULL)
		{
			return -1;
		}
		//ZeroMemory(&urlComponents, sizeof(URL_COMPONENTS));
		//urlComponents.dwStructSize = sizeof(URL_COMPONENTS);
		//urlComponents.lpszHostName = szHostName;
		//urlComponents.dwHostNameLength = sizeof(szHostName) / sizeof(WCHAR);
		//urlComponents.lpszUrlPath = szUrlPath;
		//urlComponents.dwUrlPathLength = sizeof(szUrlPath) / sizeof(WCHAR);

		//// Url 주소에서 urlComponents의 호스트 네임을 설정한다. 
		//if (!WinHttpCrackUrl(szUrl, lstrlenW(szUrl), 0, &urlComponents)) {
		//	WinHttpCloseHandle(hSession);
		//	return -2;
		//}

		//auto hConnect = WinHttpConnect(hSession, L"www.microsoft.com", INTERNET_DEFAULT_HTTPS_PORT, 0);
		auto hConnect = WinHttpConnect(hSession, L"localhost", 19000, 0);
		if (hConnect == NULL) 
		{
			auto ret = GetLastError();
			WinHttpCloseHandle(hSession);
			return -3;
		}

		auto hRequest = WinHttpOpenRequest(hConnect, L"POST", L"/Request/Login", NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);
		if (hRequest == NULL) {
			WinHttpCloseHandle(hConnect);
			WinHttpCloseHandle(hSession);
			return -4;
		}


		auto szData = R"(
		  {
			"UserSeq": 1,
			"UserID": "jacking75",
			"UserPW": "123qwe"
		  }
		)";

		DWORD          dwDataLength = lstrlenA(szData);

		auto dwTotalLength = dwDataLength;
		//auto isResult = WinHttpSendRequest(hRequest, szHeader, dwHeaderLength, WINHTTP_NO_REQUEST_DATA, 0, dwTotalLength, 0);
		auto isResult = WinHttpSendRequest(hRequest, szHeader, dwHeaderLength, WINHTTP_NO_REQUEST_DATA, 0, dwTotalLength, 0);
		if (isResult == FALSE)
		{
			auto ret = GetLastError();
			return -5;
		}
				
		DWORD          dwSize = 0;
		isResult = WinHttpWriteData(hRequest, szData, dwDataLength, &dwSize);
		if (isResult == FALSE)
		{
			return -6;
		}

		isResult = WinHttpReceiveResponse(hRequest, NULL);
		if (isResult == FALSE)
		{
			return -7;
		}

		DWORD          dwStatusCode = 0;;
		dwSize = sizeof(DWORD);
		WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &dwStatusCode, &dwSize, WINHTTP_NO_HEADER_INDEX);
		if (dwStatusCode == HTTP_STATUS_OK) {
			BYTE           buffer[4096] = { 0, };
			WinHttpReadData(hRequest, buffer, sizeof(buffer), NULL);

			std::cout << "성공 Body" << buffer << std::endl;
		}
		else {
			TCHAR szBuf[256] = { 0, };
			wsprintf(szBuf, TEXT("Status Code %d"), dwStatusCode);
			std::wcout << "실패" << szBuf << std::endl;
		}

		WinHttpCloseHandle(hRequest);
		WinHttpCloseHandle(hConnect);
		WinHttpCloseHandle(hSession);

		return 0;
	}

	
	
};