// ConsoleApplicationWinHttp.cpp : 콘솔 응용 프로그램에 대한 진입점을 정의합니다.
//

#include "stdafx.h"

#include "HttpPost.h"


int main()
{
	HttpPost::Request();

    return 0;
}

