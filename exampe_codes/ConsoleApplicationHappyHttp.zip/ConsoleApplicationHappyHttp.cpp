
#include "happyhttp.h"
#include <cstdio>
#include <cstring>

#ifdef _WIN32
#pragma comment(lib, "ws2_32")

#include <winsock2.h>
#endif // WIN32


std::string ansi_to_utf8(std::string& ansi)
{
	WCHAR unicode[1500] = { 0, };
	char utf8[1500] = { 0, };

	memset(unicode, 0, sizeof(unicode));
	memset(utf8, 0, sizeof(utf8));

	::MultiByteToWideChar(CP_ACP, 0, ansi.c_str(), -1, unicode, sizeof(unicode));
	::WideCharToMultiByte(CP_UTF8, 0, unicode, -1, utf8, sizeof(utf8), NULL, NULL);

	return std::string(utf8);
}



int count = 0;

void OnBegin(const happyhttp::Response* r, void* userdata)
{
	printf("BEGIN (%d %s)\n", r->getstatus(), r->getreason());
	count = 0;
}

void OnData(const happyhttp::Response* r, void* userdata, const unsigned char* data, int n)
{
	fwrite(data, 1, n, stdout);
	count += n;
}

void OnComplete(const happyhttp::Response* r, void* userdata)
{
	printf("COMPLETE (%d bytes)\n", count);
}



void Test1()
{
	puts("-----------------Test1------------------------");
	// simple simple GET
	happyhttp::Connection conn("scumways.com", 80);
	conn.setcallbacks(OnBegin, OnData, OnComplete, 0);

	conn.request("GET", "/happyhttp/test.php", 0, 0, 0);

	while (conn.outstanding())
		conn.pump();
}



void Test2()
{
	puts("-----------------Test2------------------------");
	// POST using high-level request interface

	const char* headers[] =
	{
		"Connection", "close",
		"Content-type", "application/x-www-form-urlencoded",
		"Accept", "text/plain",
		0
	};

	const char* body = "answer=42&name=Bubba";

	happyhttp::Connection conn("scumways.com", 80);
	conn.setcallbacks(OnBegin, OnData, OnComplete, 0);
	conn.request("POST",
		"/happyhttp/test.php",
		headers,
		(const unsigned char*)body,
		strlen(body));

	while (conn.outstanding())
		conn.pump();
}

void Test3()
{
	puts("-----------------Test3------------------------");
	// POST example using lower-level interface

	const char* params = "answer=42&foo=bar";
	int l = strlen(params);

	happyhttp::Connection conn("scumways.com", 80);
	conn.setcallbacks(OnBegin, OnData, OnComplete, 0);

	conn.putrequest("POST", "/happyhttp/test.php");
	conn.putheader("Connection", "close");
	conn.putheader("Content-Length", l);
	conn.putheader("Content-type", "application/x-www-form-urlencoded");
	conn.putheader("Accept", "text/plain");
	conn.endheaders();
	conn.send((const unsigned char*)params, l);

	while (conn.outstanding())
		conn.pump();
}

void Test4()
{
	puts("-----------------Test4------------------------");
	// POST example using lower-level interface

	auto reqJsonData = R"(
		  {
			"UserSeq": 1,
			"UserID": "jacking75",
			"UserPW": "123qwe"
		  }
		)";
	
	const char* headers[] =
	{
		"Connection", "close",
		"Content-type", "application/json",
		"Accept", "text/plain",
		0
	};

	//const char* body = "answer=42&name=Bubba";

	happyhttp::Connection conn("localhost", 19000);
	conn.setcallbacks(OnBegin, OnData, OnComplete, 0);
	conn.request("POST",
		"/Request/Login",
		headers,
		(const unsigned char*)reqJsonData,
		strlen(reqJsonData));

	while (conn.outstanding())
		conn.pump();
}

void Test5()
{
	puts("-----------------Test5------------------------");
	// POST example using lower-level interface

	auto reqJsonData = R"(
		  {
			"UserSeq": 1,
			"UserID": "�̱ٿ�",
			"UserPW": "123qwe"
		  }
		)";

	// utf8�� ��ȯ ���� ������ json �����Ϳ� �ѱ��� ������ ������ ��û�� �� ����.
	auto reqJsonDataUTF8 = ansi_to_utf8(std::string(reqJsonData));

	const char* headers[] =
	{
		"Connection", "close",
		"Content-type", "application/json",
		"Accept", "text/plain",
		0
	};

	//const char* body = "answer=42&name=Bubba";

	happyhttp::Connection conn("127.0.0.1", 19000);
	conn.setcallbacks(nullptr, OnData, nullptr, 0);
	conn.request("POST",
		"/Request/Login",
		headers,
		(const unsigned char*)reqJsonDataUTF8.c_str(),
		reqJsonDataUTF8.length());

	while (conn.outstanding())
		conn.pump();
}



int main(int argc, char* argv[])
{
#ifdef _WIN32
	WSAData wsaData;
	int code = WSAStartup(MAKEWORD(1, 1), &wsaData);
	if (code != 0)
	{
		fprintf(stderr, "shite. %d\n", code);
		return 0;
	}
#endif //WIN32
	try
	{
		//Test1();
		//Test2();
		//Test3();

		//Test4();
		Test5();
	}

	catch (happyhttp::Wobbly& e)
	{
		fprintf(stderr, "Exception:\n%s\n", e.what());
	}

#ifdef _WIN32
	WSACleanup();
#endif // WIN32

	return 0;
}