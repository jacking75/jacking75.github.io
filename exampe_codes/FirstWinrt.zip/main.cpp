#pragma comment(lib, "windowsapp")

#include <winrt/Windows.Foundation.h>

using namespace winrt;
using namespace Windows::Foundation;


int main()
{
	init_apartment();

	Uri uri(L"https://moderncpp.com/");

	printf("%ls\n", uri.Domain().c_str());

	return 0;
}