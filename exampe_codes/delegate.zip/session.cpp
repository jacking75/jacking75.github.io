#include "session.h"
#include "server.h"

void Session::Init(const int index,
	const SA::delegate<void(int)> &newConnected,
	const SA::delegate<void(int, const char *)> &processPacketDel)
{
	SessionIndex = index;
	OnConnectd = newConnected;
	ProcessPacket = processPacketDel;
}

void Session::Connected(bool isTest)
{
	auto index = isTest ? -1 : 1;
	OnConnectd(index);
}

void Session::ReceivePacket()
{
	char szMsg[] = "abcde";
	ProcessPacket(SessionIndex, szMsg);
}


void Session::SetServer(Server* pServer)
{
	m_pServer = pServer;
}

void Session::Connected2(bool isTest)
{
	auto index = isTest ? -1 : 1;
	m_pServer->OnConnectd(index);
}