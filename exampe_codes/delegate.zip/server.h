#pragma once
#include <vector>

#include "session.h"

class Server
{
public:
	void OnConnectd(int sessionIndex);
	void ProcessPacket(int sessionIndex, const char* packetData);

};