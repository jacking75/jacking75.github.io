#pragma once
#include "delegateLib\Delegate.h"

class Server;
class Session
{
public:
	Session() {};

	void Init(const int index,
		const SA::delegate<void(int)> &newConnected,
		const SA::delegate<void(int, const char *)> &processPacketDel);
	
	SA::delegate<void(int)> OnConnectd;
	SA::delegate<void(int, const char*)> ProcessPacket;
	

	void Connected(bool isTest);	
	void ReceivePacket();
	

	void SetServer(Server* pServer);
	void Connected2(bool isTest);

private:
	int SessionIndex = 0;

	Server *m_pServer;
};