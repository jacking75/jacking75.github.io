#include <iostream>

#include "server.h"


void Server::OnConnectd(int sessionIndex)
{
	if (sessionIndex >= 0)
	{
		std::cout << "sessionIndex: " << sessionIndex << "  " << "Server::OnConnectd" << std::endl;
	}
}

void Server::ProcessPacket(int sessionIndex, const char* packetData)
{
	//std::cout << "sessionIndex: " << sessionIndex << "  " << "Server::ProcessPacket" << std::endl;
}